<?php

class profile extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->helper(array('url', 'html'));
        $this->load->library(array('session', 'form_validation'));
        $this->load->database();
        $this->load->model('user_model');
    }

    function index() {
        $details = $this->user_model->get_user_by_id($this->session->userdata('uid'));
        $data['uname'] = $details[0]->fname . " " . $details[0]->lname;
        $data['uemail'] = $details[0]->email;
        $det['tot_vote'] = $this->user_model->get_total_likes1();
        //echo $det['tot_vote'];
        $data['count'] = $det['tot_vote'];
//        $t['time']= $this->user_model->see_who_liked_when();
//        $data['like_time']=$t['time'];
        $data['status'] = $this->user_model->get_status();
        $data['books'] = $this->user_model->get_all_likes();
        $this->load->view('profile_view', $data);
    }

    function admin() {
        $details = $this->user_model->get_user_by_id($this->session->userdata('uid'));
        $data['uname'] = $details[0]->fname . " " . $details[0]->lname;
        $data['uemail'] = $details[0]->email;
        $det['tot_vote'] = $this->user_model->get_total_likes1();
        //echo $det['tot_vote'];
        $data['count'] = $det['tot_vote'];
        $data['status'] = $this->user_model->get_status();
        $data['books'] = $this->user_model->get_all_likes();
        $this->load->view('admin', $data);
    }

    function save_like($id) {
        $uname = $this->session->userdata('uname');
        $data = array(
            'usr_id' => $id,
            'usr_name' => $uname,
            'likes' => '1',
            'dislike' => '0',
        );
        $insert = $this->user_model->likevote_add($data);
        echo json_encode(array("status" => TRUE));

        $det['tot_vote'] = $this->user_model->get_total_likes1();
        //echo $det['tot_vote'];
        $data['count'] = $det['tot_vote'];
        $this->load->view('profile_view', $data);
    }

    public function save_dislike($id) {
        $uname = $this->session->userdata('uname');
        $da = array(
            'usr_id' => $id,
            'usr_name' => $uname,
            'likes' => '0',
            'dislike' => '1',
        );
        $insert = $this->user_model->dislikevote_add($da);
        echo json_encode(array("status" => TRUE));

        $det['tot_vote'] = $this->user_model->get_total_likes1();
        //echo $det['tot_vote'];
        $data['count'] = $det['tot_vote'];
        $this->load->view('profile_view', $data);
    }

    function approve($id) {

        $uname = $this->session->userdata('uname');
        $fd = $this->input->post('food');
        $det['tot_vote'] = $this->user_model->get_total_likes1();
        //echo $det['tot_vote'];
        $data['count'] = $det['tot_vote'];
        $data = array(
            'a_id' => $id,
            'counter' => $data['count'],
            'food' => $fd,
            'status' => 'approve',
        );
        $insert = $this->user_model->approve_order($data);
        echo json_encode(array("status" => TRUE));
        $this->load->view('profile_view', $data);
    }

    function cancel($id) {
        $uname = $this->session->userdata('uname');
        $food = $this->input->post('food');
        $det['tot_vote'] = $this->user_model->get_total_likes1();
        //echo $det['tot_vote'];
        $data['count'] = $det['tot_vote'];
        $data = array(
            'a_id' => $id,
            'counter' => $data['count'],
            'food' => 'NF',
            'status' => 'cancel',
        );
        $insert = $this->user_model->cancel_order($data);
        echo json_encode(array("status" => TRUE));
        $this->load->view('profile_view', $data);
    }

//public function get_total_likes(){
//}
}

?>
