<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class user_model extends CI_Model {

    function __construct() {
        parent::__construct();
    }

    function get_user($email, $pwd) {
        $this->db->where('email', $email);
        $this->db->where('password', $pwd);
        $query = $this->db->get('user');
        return $query->result();
    }

    // get user
    function get_user_by_id($id) {
        $this->db->where('id', $id);
        $query = $this->db->get('user');
        return $query->result();
    }

    // insert
    function insert_user($data) {
        return $this->db->insert('user', $data);
    }

    public function likevote_add($data) {
        //echo $data[usr_id];
        $this->db->where('usr_id', $data[usr_id]);
        $query = $this->db->get('vote');

        if ($query->num_rows() > 0) {

            $this->db->where('usr_id', $data[usr_id]);
            $this->db->update('vote', $data);
        } else {
            $this->db->insert('vote', $data);
            return $this->db->insert_id();
        }
    }

    public function dislikevote_add($da) {
        //extract($da);
        $this->db->where('usr_id', $da[usr_id]);
        $query = $this->db->get('vote');

        if ($query->num_rows() > 0) {

            $this->db->where('usr_id', $da[usr_id]);
            $this->db->update('vote', $da);
        } else {
            $this->db->insert('vote', $da);
            return $this->db->insert_id();
        }
    }

    function get_total_likes1() {
        $this->db->select('COUNT(likes) as count');
        $this->db->from('vote');
        $this->db->where('likes=1');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            $row = $query->row();
            return $row->count;
        }
        return 0;
    }

    public function see_who_liked_when() {
        //TIME_TO_SEC(TIMEDIFF(NOW(),`timestamp`))

        $this->db->select('TIME_TO_SEC(TIMEDIFF(NOW(),`ts`))');
        $this->db->from('vote');
        $this->db->where('likes=1');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return 0;
    }

    public function approve_order($da) {
        //extract($da);
        $this->db->where('a_id', $da[a_id]);
        $query = $this->db->get('admin');

        if ($query->num_rows() > 0) {

            $this->db->where('a_id', $da[a_id]);
            $this->db->update('admin', $da);
        } else {
            $this->db->insert('admin', $da);
            return $this->db->insert_id();
        }
    }

    public function cancel_order($da) {
//extract($da);
        $this->db->where('a_id', $da[a_id]);
        $query = $this->db->get('admin');

        if ($query->num_rows() > 0) {

            $this->db->where('a_id', $da[a_id]);
            $this->db->update('admin', $da);
        } else {
            $this->db->insert('admin', $da);
            return $this->db->insert_id();
        }
    }

    function get_status() {
        //$this->db->select('status,food');
        $this->db->from('admin');
        // $this->db->where('likes=1');
        $query = $this->db->get();
        return $query->result();
    }

    public function get_all_likes() {
        $this->db->select('usr_name,ts');
        $this->db->from('vote');
        $this->db->where('likes=1');
        $query = $this->db->get();
        return $query->result();
    }

    public function get_admin_status(){
      $this->db->select('status');
      $this->db->from('admin');
      // $this->db->where('likes=1');
      $query = $this->db->get();
      return $query->result();
    }

}

?>
