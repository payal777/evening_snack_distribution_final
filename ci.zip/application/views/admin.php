<?php
  global $st;
 ?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>My Profile | Evening Snacks</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <link href="http://localhost/ci/assets/datatables/css/dataTables.bootstrap.css" rel="stylesheet">
    </head>
    <body>
        <nav class="navbar navbar-default" role="navigation">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar1">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="<?php echo base_url(); ?>index.php/home">EVENING SNACKS</a>
                </div>
                <div class="collapse navbar-collapse" id="navbar1">
                    <ul class="nav navbar-nav navbar-right">
                        <li><p class="navbar-text">Hello <?php echo $this->session->userdata('uname'); ?></p></li>
                        <?php echo $_SESSION['uid']; ?>
                        <li><a href="<?php echo base_url(); ?>index.php/book">Add Users</a></li>
                        <li><a href="<?php echo base_url(); ?>index.php/home/logout">Log Out</a></li>
                    </ul>
                </div>
            </div>
        </nav>
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <h5>Profile Summary</h5>
                    <hr/>
                    <p>Name: <?php echo $uname; ?> </p>
                    <p>Email: <?php echo $uemail; ?></p>
                </div>
                <div class="col-md-8">
                    <p style="color:#ff8533;"><b>If you want to order evening snacks, click on thumbs Up</b></p>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-4">
                    <?php if ($count > 5) {
                        ?>
                        <p style="font-size:200px;color: #3c763d;"><?php echo $count; ?><p>
                        <?php } else {
                            ?>
                        <p style="font-size:200px;color: #cc0606;"><?php echo $count; ?><p>
                        <?php } ?>
                </div>
                <div class="col-sm-4">
                  <?php foreach ($status as $s)
                  {
                    $st=$s->status;
                   }
                   ?>
                    <?php echo form_open(); ?>
                    <div>
                        <label class="control-label" for="food">Enter Food</label>
                        <input id="selected_food" type="text" placeholder="Enter Food" class="form-control" style="width:50%;" name="food" value="" />
                        <button type="button" style="margin-top: 10px;margin-left: 40px;" class="btn btn-primary btn-md" onclick="approve(<?php echo $_SESSION['uid']; ?>)">Approve</button>
                    </div>


                    <p style="padding-top: 15px;margin-left:50px;"><span style="font-size:50px;" class="glyphicon glyphicon-cutlery"></span></p>

                    <p><span style="font-size:100px;" class="glyphicon glyphicon-arrow-left"></span></p>
                    <button type="button" style="margin-left: 40px;" class="btn btn-primary btn-md" onclick="cancel(<?php echo $_SESSION['uid']; ?>)">Cancel</button>

                    <?php echo form_close(); ?>
                </div>
                <div class="col-sm-4">
                  <?php if ($st == "approve") {
                        echo '<p style="font-size:20px;color: #cc0606;">Order Close for Today!!!!!</p>';
                      ?>

                    <?php } else {
                        ?>
                        <button class="btn btn-warning" onclick="save_like(<?php echo $_SESSION['uid']; ?>)"><span style="font-size:200px;"><i class="glyphicon glyphicon-thumbs-up"></i></span></button>
                    <button class="btn btn-warning" style="vertical-align:bottom;background-color:#d62b05;border-color:#d62b05;" onclick="save_dislike(<?php echo $_SESSION['uid']; ?>)"><span style="font-size:50px;"><i class="glyphicon glyphicon-thumbs-down"></i></span></button>
  <?php } ?>
                </div>
            </div>
            <br>
            <div>
                <?php foreach ($status as $s) { ?>
                    <div style="border:1px solid #cecece;">
                        <span class="glyphicon glyphicon-globe"></span>
                        <span style="font-size:20px;color: #2fa8ce;padding:5px;"><?php echo $s->status; ?></span>
                        <span style="font-size:20px;color: #2fa8ce;padding:5px;"><?php echo $s->food; ?></span>
                    </div>
                    <br>
                <?php } ?>
            </div>
            <br>
            <?php foreach ($books as $book) { ?>
                <div style="border:1px solid #cecece;">
                    <span class="glyphicon glyphicon-thumbs-up"></span>
                    <span><?php echo $book->usr_name; ?></span>

                     <?php
                      $timestamp=$book->ts;
                      $splitTimeStamp = explode(" ",$timestamp);
                      $date = $splitTimeStamp[0];
                      $time = $splitTimeStamp[1];
                      $current_time=date(" H:i:s", time());
                      ?>

                    <span><?php echo $time; ?></span>
                </div>
                <br>
            <?php } ?>
            <br>
            <table class="table table-striped table-bordered" cellspacing="0" width="100%">
                <thead>
                    <tr>
                        <th>Total Thumbs Up</th>
                        <th>Snack</th>
                        <th>Status</th>
                        <th>Time</th>
                    </tr>
                </thead>

                <tbody>
                    <?php foreach ($status as $s) { ?>
                        <tr>
                            <td><?php echo $s->counter; ?></td>
                            <td><?php echo $s->food; ?></td>
                            <td><?php echo $s->status; ?></td>
                            <td><?php echo $s->timestamp; ?></td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
            <script type="text/javascript">

                function save_like(id)
                {
                    alert('you have placed an order');
                    var url;
                    url = "<?php echo ('http://localhost/ci/index.php/profile/save_like') ?>/" + id;
                    // ajax adding data to database
                    $.ajax({
                        url: url,
                        type: "GET",
                        //data: "",
                        //dataType: "JSON",
                        success: function (data)
                        {
                            //if success close modal and reload ajax table
                            //$('#modal_form').modal('hide');
                            location.reload();// for reload a page
                            //alert("success");
                        },
                        error: function (jqXHR, textStatus, errorThrown)
                        {
                            //alert('Error adding / update data');
                        }
                    });
                }

                function save_dislike(id)
                {
                    alert('You have not ordered');
                    var url;
                    url = "<?php echo ('http://localhost/ci/index.php/profile/save_dislike') ?>/" + id;
                    // ajax adding data to database
                    $.ajax({
                        url: url,
                        type: "GET",
                        //data: $('#form').serialize(),
                        //dataType: "JSON",
                        success: function (data)
                        {
                            //if success close modal and reload ajax table
                            //$('#modal_form').modal('hide');
                            location.reload();// for reload a page
                        },
                        error: function (jqXHR, textStatus, errorThrown)
                        {
                            //alert('Error adding / update data');
                        }
                    });
                }

                function approve(id) {
                    alert('You have approved an order');
                    var url;
                    url = "<?php echo ('http://localhost/ci/index.php/profile/approve') ?>/" + id;
                    // ajax adding data to database
                    $.ajax({
                        url: url,
                        method: 'POST',
                        data: {food: $("#selected_food").val()},
                        //dataType: "JSON",
                        success: function (data)
                        {
                            //if success close modal and reload ajax table
                            //$('#modal_form').modal('hide');
                            location.reload();// for reload a page
                            //alert("success");
                        },
                        error: function (jqXHR, textStatus, errorThrown)
                        {
                            //alert('Error adding / update data');
                        }
                    });
                }


                function cancel(id) {
                    alert('you have canceled an order');
                    var url;
                    url = "<?php echo ('http://localhost/ci/index.php/profile/cancel') ?>/" + id;
                    // ajax adding data to database
                    $.ajax({
                        url: url,
                        type: "GET",
                        //data: "",
                        //dataType: "JSON",
                        success: function (data)
                        {
                            //if success close modal and reload ajax table
                            //$('#modal_form').modal('hide');
                            location.reload();// for reload a page
                            //alert("success");
                        },
                        error: function (jqXHR, textStatus, errorThrown)
                        {
                            //alert('Error adding / update data');
                        }
                    });
                }
            </script>
        </div>
        <script type="text/javascript" src="<?php echo base_url("assets/js/jquery-1.10.2.js"); ?>"></script>
        <script type="text/javascript" src="<?php echo base_url("assets/js/bootstrap.js"); ?>"></script>
    </body>
</html>
